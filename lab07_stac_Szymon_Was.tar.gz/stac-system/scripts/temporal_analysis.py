import json, os
from datetime import datetime

def run_analysis():
    try:
        with open("results/federated_results.json", "r") as f:
            items = json.load(f)
    except FileNotFoundError:
        return print("Error: JSON not found.")

    if not items:
        return print("Catalog empty.")

    times = []
    for i in items:
        if d := i.get("datetime"):
            times.append(datetime.fromisoformat(d.replace("Z", "+00:00")))
    
    times.sort()
    span = times[-1] - times[0]
    gaps = [times[i] - times[i-1] for i in range(1, len(times))]
    
    max_gap = max(gaps) if gaps else 0
    avg_h = sum(g.total_seconds() for g in gaps) / len(gaps) / 3600 if gaps else 0

    report = f"""TEMPORAL COVERAGE REPORT
========================
Total Observations: {len(times)}
Earliest: {times[0].isoformat()}
Latest: {times[-1].isoformat()}
Span: {span.days} days, {span.seconds // 3600} hours
Max Gap: {max_gap}
Avg Revisit: {avg_h:.1f} hours

Q: Continuous monitoring?
A: No, periodic (~{avg_h:.1f}h revisit). Optical limits apply.

Q: Periods without observations?
A: Yes, maximum gap is {max_gap}.

Q: Additional sensors needed?
A: Yes, commercial SAR/Optical would fix these temporal gaps.
"""
    os.makedirs("reports", exist_ok=True)
    with open("reports/temporal_analysis.txt", "w") as f:
        f.write(report)
    print("Success! Saved to reports/temporal_analysis.txt")

if __name__ == "__main__":
    run_analysis()
