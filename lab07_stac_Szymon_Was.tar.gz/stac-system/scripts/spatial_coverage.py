import requests, json, os

STAC_URL = "https://catalogue.dataspace.copernicus.eu/stac/search"

# 10 AOIs in Southern Poland [W, S, E, N]
REGIONS = {
    "Krakow": [19.8, 50.0, 20.1, 50.2],
    "Katowice": [18.9, 50.2, 19.1, 50.4],
    "Tatra_Mountains": [19.8, 49.2, 20.2, 49.4],
    "Bielsko_Biala": [18.9, 49.7, 19.1, 49.9],
    "Rzeszow": [21.9, 50.0, 22.1, 50.2],
    "Tarnow": [20.9, 49.9, 21.1, 50.1],
    "Nowy_Sacz": [20.6, 49.5, 20.8, 49.7],
    "Czestochowa": [19.0, 50.7, 19.2, 50.9],
    "Kielce": [20.5, 50.8, 20.7, 51.0],
    "Opole": [17.8, 50.6, 18.0, 50.8]
}

successful = 0
empty = 0
failed = 0

print("Executing Spatial Coverage Analysis...")

for name, bbox in REGIONS.items():
    payload = {
        "collections": ["sentinel-2-l2a"],
        "bbox": bbox,
        "datetime": "2024-01-01/2024-01-10",
        "limit": 5
    }
    try:
        res = requests.post(STAC_URL, json=payload, timeout=15)
        if res.status_code == 200:
            features = res.json().get("features", [])
            if len(features) > 0:
                successful += 1
                print(f"[{name}] -> OK ({len(features)} items)")
            else:
                empty += 1
                print(f"[{name}] -> EMPTY")
        else:
            failed += 1
            print(f"[{name}] -> API ERROR")
    except Exception as e:
        failed += 1
        print(f"[{name}] -> TIMEOUT/ERROR")

total_queries = len(REGIONS)
coverage_score = (successful / total_queries) * 100 if total_queries else 0

print(f"\nScore: {coverage_score}% | OK: {successful} | Empty: {empty} | Failed: {failed}")
