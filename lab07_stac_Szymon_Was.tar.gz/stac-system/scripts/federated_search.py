import requests
import json
import os

STAC_URL = "https://catalogue.dataspace.copernicus.eu/stac/search"

QUERIES = {
    "Optical_Poland": {
        "collections": ["sentinel-2-l2a"],
        "bbox": [19.0, 50.0, 20.0, 51.0],
        "datetime": "2024-01-01/2024-01-10",
        "limit": 50
    },
    "Optical_Baltic": {
        "collections": ["sentinel-2-l2a"],
        "bbox": [17.0, 54.0, 19.0, 55.5],
        "datetime": "2024-01-01/2024-01-10",
        "limit": 50
    },
    "Radar_Poland": {
        "collections": ["sentinel-1-grd"],
        "bbox": [19.0, 50.0, 20.0, 51.0],
        "datetime": "2024-01-01/2024-01-10",
        "limit": 50
    }
}

raw_items = []
unique_items_map = {}
query_stats = {}

print("Starting Federated Discovery...")

for query_name, payload in QUERIES.items():
    print(f"Executing query: {query_name}...")
    try:
        response = requests.post(STAC_URL, json=payload, timeout=30)
        response.raise_for_status()
        features = response.json().get("features", [])
        
        query_stats[query_name] = len(features)
        
        for item in features:
            raw_items.append(item)
            item_id = item["id"]
            
            # Deduplikacja - jeśli id jeszcze nie istnieje w słowniku, dodajemy
            if item_id not in unique_items_map:
                normalized_item = {
                    "id": item_id,
                    "collection": item["collection"],
                    "datetime": item["properties"]["datetime"],
                    "bbox": item.get("bbox", []),
                    "assets_count": len(item.get("assets", {})),
                    "source_provider": "CDSE",
                    "source_query": query_name
                }
                unique_items_map[item_id] = normalized_item

    except Exception as e:
        print(f"Error executing {query_name}: {e}")

# Konwersja unikalnych items do listy i sortowanie po czasie akwizycji
unified_catalog = list(unique_items_map.values())
unified_catalog.sort(key=lambda x: x["datetime"])

# Zapis do plików
os.makedirs("results", exist_ok=True)

with open("results/raw_stac_items.json", "w") as f:
    json.dump(raw_items, f, indent=2)

with open("results/federated_results.json", "w") as f:
    json.dump(unified_catalog, f, indent=2)

# Podsumowanie w konsoli
print("\n--- FEDERATION SUMMARY ---")
for q_name, count in query_stats.items():
    print(f"{q_name}: {count} products found")
print(f"Total raw items: {len(raw_items)}")
print(f"Duplicates removed: {len(raw_items) - len(unified_catalog)}")
print(f"Final unique products: {len(unified_catalog)}")
print("Data saved to results/ directory.")
