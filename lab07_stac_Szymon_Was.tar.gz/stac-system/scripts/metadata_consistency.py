import json, os

def check_consistency():
    try:
        with open("results/raw_stac_items.json", "r") as f:
            items = json.load(f)
    except:
        return print("Error: raw_stac_items.json not found.")

    core_fields = ["id", "collection", "bbox", "geometry", "assets", "links"]
    # properties.datetime is handled separately as it's nested
    
    total = len(items)
    complete_core = 0
    missing_fields = {}

    for item in items:
        # Check core fields
        is_core_ok = all(f in item for f in core_fields) and "datetime" in item.get("properties", {})
        if is_core_ok: complete_core += 1
        
        # Check optional EO/SAR fields
        for field in ["eo:cloud_cover", "sat:orbit_state", "platform", "instruments"]:
            if field not in item.get("properties", {}):
                missing_fields[field] = missing_fields.get(field, 0) + 1

    report = f"""METADATA CONSISTENCY REPORT
---------------------------
Total items checked: {total}
Items with complete core metadata: {complete_core}
Items with missing optional metadata: {len(missing_fields)}

Common fields (present in all):
- id
- collection
- bbox
- geometry
- properties.datetime
- assets
- links

Fields missing in some items:
"""
    for f, count in missing_fields.items():
        report += f"- properties.{f} (missing in {count} items)\n"

    report += """
Interpretation:
The catalog is structurally consistent at the STAC level, but observation-specific 
metadata differs significantly between sensor types. For example, radar data 
lacks cloud cover metrics, while optical data may lack orbital state details. 
Automated pipelines must use conditional logic when switching between collections.
"""
    os.makedirs("reports", exist_ok=True)
    with open("reports/metadata_consistency.txt", "w") as f:
        f.write(report)
    print("Consistency report generated in reports/metadata_consistency.txt")

if __name__ == "__main__":
    check_consistency()
