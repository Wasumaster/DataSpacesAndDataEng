import requests

url = "https://catalogue.dataspace.copernicus.eu/stac/search"
query = {
    "collections": ["sentinel-2-l2a"],
    "limit": 5
}

try:
    response = requests.post(url, json=query, timeout=20)
    response.raise_for_status()
    data = response.json()
    
    print("--- STAC QUERY RESULTS ---")
    for item in data.get("features", []):
        product_id = item["id"]
        acq_time = item["properties"]["datetime"]
        
        # Parsowanie nazwy produktu (ID), aby wyciągnąć informacje
        parts = product_id.split('_')
        
        # parts[0] to zazwyczaj 'S2A' lub 'S2B'
        sat_prefix = parts[0]
        satellite_name = "Sentinel-2A" if sat_prefix == "S2A" else "Sentinel-2B" if sat_prefix == "S2B" else sat_prefix
        
        # parts[5] to zazwyczaj kafelek (Tile) np. 'T18RTT'
        tile_id = parts[5] if len(parts) > 5 and parts[5].startswith('T') else "Unknown"
        
        # Zliczanie zasobów (assets)
        num_assets = len(item.get("assets", {}))
        
        print(f"Product ID:  {product_id}")
        print(f"Time:        {acq_time}")
        print(f"Satellite:   {satellite_name}")
        print(f"Tile:        {tile_id}")
        print(f"Assets:      {num_assets}")
        print("-" * 40)

except requests.exceptions.RequestException as e:
    print("REQUEST FAILED:", e)
except ValueError:
    print("INVALID JSON RESPONSE")
