#!/bin/bash

EXPECTED_PORTS="5000,6000"
OPEN_PORTS=($(nmap -n -p- 127.0.0.1 | grep "open" | cut -d'/' -f1))

COUNT=0


for port in "${OPEN_PORTS[@]}"; do
  
  if [[ ! "$EXPECTED_PORTS" =~ "$port" ]]; then
    ((COUNT++))
  fi
done

if [ $COUNT -eq 0 ]; then
  echo "NO UNEXPECTED EXPOSED PORTS"
else
  echo "TOTAL UNEXPECTED EXPOSED PORTS: $COUNT"
fi   
