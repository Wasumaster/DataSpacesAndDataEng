#!/bin/bash

if [ -z "$1" ]; then
  echo "Usage: $0 <ERROR_THRESHOLD>"
  exit 1
fi

TH=$1
max=0
max_file=""

echo "Processing log files.."

for file in ../logs/*.log
do
 count=$(grep "ERROR" "$file" | wc -l)
 name=$(basename "$file") 
 echo "$name: $count ERROR entries"
 
 if [ $count -gt $TH ]; then
    echo "ALERT: log anomaly detected in $name"
 fi

 if [ $count -gt $max ]; then
    max=$count
    max_file=$name
 fi
done

echo "" 
echo "Most unstable log file: $max_file ($max ERROR entries)"   


   
