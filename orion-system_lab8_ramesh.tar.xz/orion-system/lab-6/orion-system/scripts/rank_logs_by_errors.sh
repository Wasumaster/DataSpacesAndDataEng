#!/bin/bash
#scripts/rank_logs_by_errors.sh

[ -z "$1" ] && echo "Usage: $0 <log_file>" && exit 1
[ ! -f "$1" ] && echo "File not found" && exit 1

echo "File: $(basename "$1")"
echo "Total entries: $(wc -l < "$1")"
echo "INFO: $(grep -c "INFO" "$1")"
echo "WARN: $(grep -c "WARN" "$1")"
echo "ERROR: $(grep -c "ERROR" "$1")"
