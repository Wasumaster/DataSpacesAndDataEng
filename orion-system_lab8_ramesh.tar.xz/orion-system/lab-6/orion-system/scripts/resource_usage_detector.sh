#!/bin/bash

CPU=$1 MEM=$2

if [ -z "$CPU" ] || [ -z "$MEM" ]; then
 echo "Usage: $0 <CPU_THRESHOLD> <MEM_THRESHOLD>"
 exit 1
fi

ps -eo pid,comm,%cpu,%mem | tail -n +2 | while read pid comm cpu mem
do
 if (( $(echo "$cpu > $CPU" | bc -l) )); then
   echo "WARNING: suspicious CPU usage: $comm (PID: $pid)"
 fi

 if (( $(echo "$mem > $MEM" | bc -l) )); then
    echo "WARNING: suspicious memory usage: $comm (PID: $pid)"
 fi
done
