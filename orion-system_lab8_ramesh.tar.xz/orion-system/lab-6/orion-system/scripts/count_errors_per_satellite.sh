#!/bin/bash

echo "ERROR count per satellite:"
echo -n "sat-001:"
grep ERROR logs/sat-001.log | wc - l
echo -n "sat-002:"
grep ERROR logs/sat-002.log | wc - l

