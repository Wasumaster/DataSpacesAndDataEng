#!/bin/bash
/home/student/orion-system/logs = $1
wc -l < "$/home/student/orion-system/logs"
