#!/bin/bash

# Count total log entries
total=$(wc -l logs/*.log | tail -n 1 | awk '{print $1}')

# Count events using pipelines
info=$(grep INFO logs/*.log | wc -l)
warn=$(grep WARN logs/*.log | wc -l)
error=$(grep ERROR logs/*.log | wc -l)

# Determine less stable satellite
e1=$(grep ERROR logs/sat-001.log | wc -l)
e2=$(grep ERROR logs/sat-002.log | wc -l)

if [ $e1 -gt $e2 ]; then
    less="sat-001"
elif [ $e2 -gt $e1 ]; then
    less="sat-002"
else
    less="equal"
fi

# Write results to file (exact required format)
echo "ORION LOG SUMMARY" > reports/log_summary.txt
echo "Total log entries: $total" >> reports/log_summary.txt
echo "INFO events: $info" >> reports/log_summary.txt
echo "WARN events: $warn" >> reports/log_summary.txt
echo "ERROR events: $error" >> reports/log_summary.txt
echo "Less stable satellite: $less" >> reports/log_summary.txt
