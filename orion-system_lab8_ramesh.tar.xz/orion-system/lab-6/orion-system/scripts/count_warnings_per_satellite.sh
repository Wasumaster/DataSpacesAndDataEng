#!/bin/bash
w1 = $(grep WARN logs/sat-001.log|wc -l)
w2 = $(grep WARN logs/sat-002.log|wc -l)
echo "sat-001 WARN:$w1"
echo "sat-002 WARN:$w2"

if [$w1 -gt $w2]; then
   echo" sat-001.log  has lot of warnings"
else
   echo "sat-002.log has lot of warnings"


