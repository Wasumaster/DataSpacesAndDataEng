#!/bin/bash
WHITELIST=("sleep" "bash")

authorized=0
unauthorized=0

while read pid comm
do
  s_authorized=0


  for allowed in "${WHITELIST[@]}"
  do
    if [ "$comm" = "$allowed" ]; then
        is_authorized=1
        break
    fi
  done

  if [ $is_authorized -eq 1 ]; then
    echo "AUTHORIZED PROCESS: $comm (PID: $pid)"
    ((authorized++))
  else
    echo "UNAUTHORIZED PROCESS: $comm (PID: $pid)"
    ((unauthorized++))
  fi
done < <(ps -eo pid,comm | tail -n +2)

echo "Total Authorized:$authorized"
echo "Total Unauthorized:$unauthorized"
