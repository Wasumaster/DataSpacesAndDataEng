#!/bin/bash

COUNT=0

ss -tulnp | grep LISTEN | while read line
do
    proto=$(echo $line | awk '{print $1}')
    addr=$(echo $line | awk '{print $5}')
    proc=$(echo $line | grep -oP '"\K[^"]+')
    pid=$(echo $line | grep -oP 'pid=\K[0-9]+')

    echo "LISTENING SERVICE: $proto $addr $proc $pid"
    ((COUNT++))
done
