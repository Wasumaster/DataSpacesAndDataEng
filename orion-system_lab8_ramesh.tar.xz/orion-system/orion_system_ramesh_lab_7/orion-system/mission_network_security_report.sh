
#!/bin/bash

FILE="../reports/mission_network_security_report-$(date +%y-%m-%d-%H-%M-%S).txt"

{
echo "=== MISSION NETWORK SECURITY REPORT ==="
echo "TIME: $(date)"

echo "[NETWORK]"
echo "LISTENING: $(ss -tuln | grep LISTEN | wc -l)"
echo "ESTABLISHED: $(ss -tn | grep ESTAB | wc -l)"
echo "EXPOSED: $(./external_port_exposure_audit.sh | grep EXPOSED | wc -l)"
echo "SUSPICIOUS: $(./suspicious_remote_connection_audit.sh | grep SUSPICIOUS | wc -l)"

TOP=$(ss -tnp | grep ESTAB | awk -F'"' '{print $2}' | sort | uniq -c | sort -nr | head -1)
echo "TOP PROCESS: $TOP"

echo "[RUNTIME]"
echo "HIGH CPU: $(ps aux | awk '$3 > 50' | wc -l)"
echo "LOG ERRORS: $(grep -i error ../logs/* | wc -l)"

echo "[CLASSIFICATION]"
./network_incident_classifier.sh | grep FINAL

} > $FILE

echo "Report saved to $FILE"
