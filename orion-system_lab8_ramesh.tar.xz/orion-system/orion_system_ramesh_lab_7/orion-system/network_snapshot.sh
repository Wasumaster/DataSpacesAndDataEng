#!/bin/bash

echo "=== NETWORK SNAPSHOT ==="
echo "TIME: $(date)"

LISTEN=$(ss -tuln | grep LISTEN | wc -l)
ESTAB=$(ss -tn | grep ESTAB | wc -l)
EXPOSED=$(./external_port_exposure_audit.sh | grep EXPOSED | wc -l)
SUSPICIOUS=$(./suspicious_remote_connection_audit.sh | grep SUSPICIOUS | wc -l)

TOP=$(ss -tnp | grep ESTAB | awk -F'"' '{print $2}' | sort | uniq -c | sort -nr | head -1)

CLASS=$(./network_incident_classifier.sh | grep FINAL | awk '{print $2}')

echo "LISTENING SERVICES: $LISTEN"
echo "ESTABLISHED CONNECTIONS: $ESTAB"
echo "UNEXPECTED EXPOSED PORTS: $EXPOSED"
echo "SUSPICIOUS REMOTE CONNECTIONS: $SUSPICIOUS"
echo "TOP PROCESS: $TOP"
echo "CLASSIFICATION: $CLASS"s
