#!/bin/bash

COUNT=0

ss -tnp | grep ESTAB | while read line
do
    remote=$(echo $line | awk '{print $5}')
    ip=$(echo $remote | cut -d ':' -f1)

    proc=$(echo $line | grep -oP '"\K[^"]+')
    pid=$(echo $line | grep -oP 'pid=\K[0-9]+')

    if [[ "$ip" != "127.0.0.1" && "$ip" != "::1" ]]; then
        echo "SUSPICIOUS CONNECTION: $proc $pid -> $remote"
        ((COUNT++))
    fi
done
