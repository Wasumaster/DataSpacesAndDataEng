#!/bin/bash

ACTIVE=0
EXPOSED=$(./external_port_exposure_audit.sh | grep "EXPOSED PORT" | wc -l)
if [ "$EXPOSED" -gt 0 ]; then
    echo "EXPOSED PORTS: ACTIVE"
    ((ACTIVE++))
else
    echo "EXPOSED PORTS: INACTIVE"
fi


SUSPICIOUS=$(./suspicious_remote_connection_audit.sh | grep "SUSPICIOUS" | wc -l)
if [ "$SUSPICIOUS" -gt 0 ]; then
    echo "SUSPICIOUS CONNECTIONS: ACTIVE"
    ((ACTIVE++))
else
    echo "SUSPICIOUS CONNECTIONS: INACTIVE"
fi


CPU=$(ps aux | awk '$3 > 50 {print}' | wc -l)
if [ "$CPU" -gt 0 ]; then
    echo "HIGH CPU: ACTIVE"
    ((ACTIVE++))
else
    echo "HIGH CPU: INACTIVE"
fi


LOGS=$(grep -i "error" ../logs/* | wc -l)
if [ "$LOGS" -gt 0 ]; then
    echo "LOG ERRORS: ACTIVE"
    ((ACTIVE++))
else
    echo "LOG ERRORS: INACTIVE"
fi

echo "TOTAL ACTIVE: $ACTIVE"


if [ "$ACTIVE" -eq 0 ]; then
    echo "FINAL: NORMAL"
elif [ "$ACTIVE" -eq 1 ]; then
    echo "FINAL: WARNING"
else
    echo "FINAL: CRITICAL"
fi
