#!/bin/bash

INTERVAL=5
FILE="../reports/monitor_$(date +%H-%M-%S).txt"

while true
do
    TIME=$(date "+%H:%M:%S")

    LISTEN=$(ss -tuln | grep LISTEN | wc -l)
    ESTAB=$(ss -tn | grep ESTAB | wc -l)
    EXPOSED=$(./external_port_exposure_audit.sh | grep EXPOSED | wc -l)
    SUSPICIOUS=$(./suspicious_remote_connection_audit.sh | grep SUSPICIOUS | wc -l)
    CLASS=$(./network_incident_classifier.sh | grep FINAL | awk '{print $2}')

    echo "$TIME LISTEN=$LISTEN ESTAB=$ESTAB EXPOSED=$EXPOSED SUSPICIOUS=$SUSPICIOUS CLASS=$CLASS" >> $FILE

    sleep $INTERVAL
done
