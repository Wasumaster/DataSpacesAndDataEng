#!/bin/bash

ss -tnp | grep ESTAB | while read line
do
    local=$(echo $line | awk '{print $4}')
    remote=$(echo $line | awk '{print $5}')
    proc=$(echo $line | grep -oP '"\K[^"]+')
    pid=$(echo $line | grep -oP 'pid=\K[0-9]+')

    echo "ESTABLISHED CONNECTION: $local -> $remote $proc $pid"
done
